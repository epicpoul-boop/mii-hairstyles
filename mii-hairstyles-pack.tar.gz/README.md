# Mii hairstyles (extracted)

Source: Joey Carlino — Mii Maker for Blender (FREE)
https://joeycarlino.gumroad.com/l/mii

From: `Mii_Maker_for_4.1_v2.blend`

## Contents
- `mii_hairstyles_only.blend` — 0 hair style meshes (+ hair materials/textures)
- `meshes/hair.XXX.glb` — individual styles
- `meshes/all_hairstyles.glb` — combined
- `textures/` — hair-related textures
- `manifest.json` — index

Beard helpers and UI pickers were excluded. Respect the creator’s Gumroad terms for reuse.
